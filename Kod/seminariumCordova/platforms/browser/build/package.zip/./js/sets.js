var setList = {
    // Application Constructor
    initialize: function() {
        console.log("SETS");

    },
};

setList.initialize();